# config.py
DATABASE_NAME = 'home_service_system.db'
